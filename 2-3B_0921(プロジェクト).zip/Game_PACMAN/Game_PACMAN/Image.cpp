#include"DxLib.h"
#include"Image.h"

Image image;

Image::Image() {
	g_StageImage = 0;			// �摜�p�ϐ�
}
/***********************************************
 * �摜�ǂݍ���
 ***********************************************/
int Image::LoadImages()
{
	//�X�e�[�W�w�i
	//if ((g_StageImage = LoadGraph("images/maze_blue.png")) == -1) return -1;
	return 0;
}