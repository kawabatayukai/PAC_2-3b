#pragma once
class Image {
public:
	int	g_StageImage;			// �摜�p�ϐ�

	Image();

	int LoadImages();
};
extern Image image;